// LPC1114 1byte ichigo mouse by Hideshi Maeno 2022.8.14
#include "mbed.h"
#define ACK 0xFA
#define SELF_TEST_OK 0xAA
#define MOUSE_ID 0x00
#define MOTION_TH_MIN 8
int motion_th;
int motion_rate;
DigitalOut led(LED1); // Jam LED1
DigitalIn sw2(dp13); // Jam SW2
Serial pc(dp16, dp15);  // Jam TXD, RXD
// Only PS2 mouse is supported. (example: ELECOM M-K6P2RWH/RS) 
// SANWA SUPPLY MA-BL138 PS2/USB mouse requires 5V 1Kohm pull-up and only 3 buttons are available. No X/Y motion.

/* 1Byte Serial Data Format
Bit7 Always 1
Bit6 X motion detected
Bit5 Y sign
Bit4 X sign
Bit3 Y motion detected
Bit2 Button MIDDLE 
Bit1 Button RIGHT
Bit0 Button LEFT
*/

DigitalInOut pinC(dp28); // PS/2 CLOCK = Jam KBD1
DigitalInOut pinD(dp26); // PS/2 DATA  = Jam KBD2
//DigitalInOut pinC(dp18); // Jam OUT5
//DigitalInOut pinD(dp17); // Jam OUT6

class MOUSE {
    protected:
    public:
    void init(){
        pinC.mode(PullUp);
        pinD.mode(PullUp);
        pinC.output();
        pinD.input();
    }

    int readMouse(void){
        int data;
        uint8_t parity;
        pinC.input();
        pinD.input();
        while (pinC==1); // wait for CLK=0
        if (pinD!=0) return(-1); // start bit error
        while (pinC==0); // wait for CLK=1
        data=0;
        parity=0;
        for (int bit=0; bit<=7; bit++){
            while (pinC==1); // wait for CLK=0
            if (pinD==1) { data=data+(1<<bit); parity=parity^1; }
            while (pinC==0); // wait for CLK=1
        }
        while (pinC ==1); // wait for CLK=0
        if (pinD==parity) return(-1); // parity bit error
        while (pinC==0); // wait for CLK=1
        while (pinC==1); // wait for CLK=0
        if (pinD!=1) return(-1); // stop bit error
        while (pinC==0); // wait for CLK=1
        return(data);
    }
    
    void writeMouse(uint8_t data){
        int bit;
        uint8_t parity, d;
        pinC.output(); // Assert CLK=0
        pinC=0;
        wait_us(100); //HM
        pinD.output();   //Assert DATA=0
        pinD=0;
        wait_us(10);
        pinC.input(); // release CLK, CLK=1 (pull-up), request for data send. 
        parity=0;
        for (bit=0; bit<=8; bit++){ // 8:parity bit
            while (pinC ==1); // wait for CLK=0
            wait_us(10);
            if (bit<=7) {
                d=(data>>bit)&1;
                pinD = d;
                parity=parity^d;
            }
            else { // 8:parity bit
                parity=parity^1; // odd parity;
                pinD=parity;
            }
            while (pinC ==0); // wait for CLK=1
        }
        while (pinC ==1); // wait for CLK=0
        wait_us(10);
        pinD = 1; // stop bit
        while (pinC ==0); // wait for CLK=1
        pinD.input();
        while (pinC ==1); // wait for CLK=0
        while (pinD ==1); // wait ACK=0
        while (pinC ==0); // wait for CLK=1
        wait_us(100);
    }
};

MOUSE ms1;

int command_ack(uint8_t command) {
    int res;
    int err=0;
    ms1.writeMouse(command);
    res=ms1.readMouse();
    if (res!=ACK) err=1;
    return(err);
}

int command_ack_ignore(uint8_t command) {
    int res;
    int err=0;
    ms1.writeMouse(command);
    res=ms1.readMouse();
    if (res!=ACK) err=2;
    return(err);
}

int st_msid() {
    int res;
    int err=0;
    res=ms1.readMouse();
    if (res!=SELF_TEST_OK) err=3;
    res=ms1.readMouse();
    if (res!=MOUSE_ID) err=4;
    return(err);
}

int command_ack_st_msid(uint8_t command) {
    int res;
    int err=0;
//    pc.printf("write command %02x\n",command);
    ms1.writeMouse(command);
    res=ms1.readMouse();
    if (res!=ACK) {
//        pc.printf("Error5: not ACK: %02X\n",res);
        err=5;
    }
    res=ms1.readMouse();
    if (res!=SELF_TEST_OK) {
//        pc.printf("Error6: SELF_TEST: %02X\n",res);
        err=6;
    }
    res=ms1.readMouse();
    if (res!=MOUSE_ID) {
//        pc.printf("Error7: MOUSE_ID: %02X\n",res);
        err=7;
    }
    return(err);
}

int main() {
    int byte_code;
    int byte1, byte2, byte3;
    int btn, dx, dy, old_btn=-1;
    int sum_dx=0, sum_dy=0;
    int err;
    int led_toggle=0;
    led=0;
    sw2.mode(PullUp);
    pc.baud(115200); // Jam default
    ms1.init();
    wait_ms(100);
    if (sw2 == 0) {

        motion_rate=0;
        wait_ms(1000);
        while (sw2 == 0) {
            motion_rate++;
            led=1;
            wait_ms(500);
            led=0;
            wait_ms(500);
        }
        wait_ms(500);
        if (sw2 == 0) {
            pc.printf("1 @LOOP:K=INKEY():IF K=0 CONT\n");
            pc.printf("2 ?BIN$(K,8):GOTO@LOOP\n");
            pc.printf("run\n");
        }
    }
    else motion_rate=1;
    motion_th=MOTION_TH_MIN<<motion_rate;
    wait_ms(100);
    do {
        err=command_ack_st_msid(0xFF); // mouse reset
    } while (err > 0) ;
    command_ack(0xF4); // stream data report enable
    while(1) {
        byte1 = ms1.readMouse();
        byte2 = ms1.readMouse();
        byte3 = ms1.readMouse();
        if ((byte1|0xFF)==0xFF) { // normal data (upper bytes are all 0)
            btn = byte1 & 0x07;
            dx = (byte1 & 0x10)? (-1)^0xFF:0;
            dx = dx + byte2;
            dy = (byte1 & 0x20)? (-1)^0xFF:0;
            dy = dy + byte3;
            sum_dx += dx;
            sum_dy += dy;
            byte_code = 0x80+btn; // MSB: always 1
            if (sum_dx > motion_th) {
                sum_dx -= motion_th;
               byte_code |= 0x40; // set X overflow flag
            }
            else if (sum_dx < -motion_th) {
                sum_dx += motion_th;
                byte_code |= 0x50; // set X overflow flag and sign bit
            }
            if (sum_dy > motion_th) {
                sum_dy -= motion_th;
                byte_code |= 0x08; // set Y overflow flag
            }
            else if (sum_dy < -motion_th) {
                sum_dy += motion_th;
                byte_code |= 0x28; // set Y overflow flag and sign bit
            }
            //pc.printf("BYTE1:%02x BTN:%1x DX:%3d DY:%3d SUM_DX:%3d SUM_DY:%3d BYTE_CODE:%02x ",byte1,btn,dx,dy,sum_dx,sum_dy,byte_code); // debug
            if ( ((byte_code&0x48)!=0) // motion detected
                || (btn != old_btn) ) { // or bottun changed
                old_btn=btn;
                if (led_toggle == 1) led=1; else led=0;
                led_toggle = 1 - led_toggle;
                pc.putc(byte_code); // 1byte stream mouse code
            }
        }
    }
}

